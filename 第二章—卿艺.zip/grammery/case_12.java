package grammery;

public class case_12 {
    public static void main(String[] args) {
        //字符常量
        System.out.println("HelloWorld!");
        //整数常量
        System.out.println(67);
        //小数常量
        System.out.println("A");
        //布尔常量
        System.out.println(true);
        //空常量
        //System.out.println(null);
        //空常量不能直接输出
    }
}
