package grammery;

public class case_09 {
    public static void main(String[] args) {
        System.out.println("Hello"+123);
        System.out.println(23+"Hello");
        System.out.println("Hello"+2+3);
        System.out.println(2+3+"Hello");
    }
}
