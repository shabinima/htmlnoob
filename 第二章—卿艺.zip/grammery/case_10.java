package grammery;

import java.util.Scanner;

public class case_10 {
    public static void main(String[] args) {
        //构建对象
        Scanner sc=new Scanner(System.in);
        //接受数据
        int x=sc.nextInt();
        //输出数据
        System.out.println("x:" +x);
    }
}
