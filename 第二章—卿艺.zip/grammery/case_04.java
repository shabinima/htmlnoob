package grammery;

public class case_04 {
    public static void main(String[] args) {
        int i=(int)45.23;
        long    I=(long)456.6f;
        char    c=(char)97.14;
        System.out.println(i);
        System.out.println(I);
        System.out.println(c);
    }
}
