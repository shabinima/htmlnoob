package grammery;

import java.util.Scanner;

public class case_07 {
    public static void main(String[] args) {
        Scanner Sc=new Scanner(System.in);
        int S=Sc.nextInt();
        int H=Sc.nextInt();
        int B=Sc.nextInt();
        System.out.println("身高最高为:"+B);
    }
}
