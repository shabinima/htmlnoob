package grammery;

public class case_02 {
    public static void main(String[] args) {
        char    c='g';
        int i=103;
        System.out.println("'g'和103是否相等:"+(c==i));
    }
}
