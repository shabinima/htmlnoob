package grammery;

public class case_05 {
    public static void main(String[] args) {
        int tiger1=180;
        int tiger2=200;
        boolean b=tiger1==tiger2?true:false;
        System.out.println("b:"+b);
    }
}
